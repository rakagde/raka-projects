# Product image notes

- Most catalog product packshots are copied from the publicly available image catalog at https://kopikenangan.menumakanan.com/. Image filenames correspond to the product names in that catalog.
- Taro Cloud Latte uses a product photo from Kopi Kenangan's official X account: https://x.com/Kopikenangan_ID
- Thai Tea Loaded uses the Thai Tea Series campaign artwork on the GoFood listing for Kopi Kenangan: https://gofood.co.id/id/batam/restaurant/kopi-kenangan-ruko-palm-spring-batam-c6ea8750-ea1e-4e75-a3ee-7130e7494238
- Original Palm Sugar Milky Speculoos uses The O.G Aren Series promotional image on the GoFood listing for Rumah Kenangan: https://gofood.co.id/jakarta/restaurant/rumah-kenangan-senopati-516710b0-b587-4b1e-9d7c-d77aa8d80cbe

If Kopi Kenangan has supplied an approved media folder, those files can replace the menu catalog packshots without changing the menu data or layout.
