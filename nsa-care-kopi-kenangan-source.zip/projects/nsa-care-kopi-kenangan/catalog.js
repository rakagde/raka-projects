export const PRODUCT_CATALOG = [
  ['black-palm-sugar-milk-coffee','Black Palm Sugar Milk Coffee',26000,'Coffee','#79563d','Best Seller'],
  ['caramel-macchiato','Caramel Macchiato',34000,'Coffee','#a66d3f','Popular'],
  ['americano','Americano',25000,'Coffee','#483226','Teacher Pick'],
  ['matcha-latte','Matcha Latte',31000,'Matcha','#8a9d65','Popular'],
  ['oreo-shake','Oreo Shake',30000,'Non-Coffee','#6d625a','Student Pick'],
  ['kenangan-milk-tea','Kenangan Milk Tea',25000,'Tea','#a8764f','Student Pick'],
  ['latte','Latte',28000,'Coffee','#9a7456','Classic'],
  ['milo-dinosaurus','Milo Dinosaurus',27000,'Non-Coffee','#725143','Student Pick'],
  ['og-thai-tea','OG Thai Tea',26000,'Tea','#c77b36','Popular'],
  ['dutch-chocolate','Dutch Chocolate',30000,'Chocolate','#67473a','Non-Coffee'],
  ['creamy-aren-latte','Creamy Aren Latte',28000,'Coffee','#9a7456'],
  ['former-memories-coffee','Former Memories Coffee',26000,'Coffee','#684635'],
  ['hazelnut-latte','Hazelnut Latte',32000,'Coffee','#9a7456'],
  ['matcha-espresso','Matcha Espresso',32000,'Coffee','#7f8d57'],
  ['mocha-latte','Mocha Latte',35000,'Coffee','#684635'],
  ['vanilla-latte','Vanilla Latte',32000,'Coffee','#b69672'],
  ['cappuccino','Cappuccino',28000,'Coffee','#b69672'],
  ['caramel-latte','Caramel Latte',32000,'Coffee','#b78348'],
  ['dua-shot-iced-shaken','Dua Shot Iced Shaken',32000,'Coffee','#684635'],
  ['butterscotch-aren-latte','Butterscotch Aren Latte',26000,'Coffee','#aa7748'],
  ['avocado-coffee','Avocado Coffee',34000,'Coffee','#788456'],
  ['taro-cloud-latte','Taro Cloud Latte',29000,'Non-Coffee','#9b83a8'],
  ['caramel-dutch-choco','Caramel Dutch Choco',35000,'Chocolate','#8e5a3c'],
  ['hazelnut-choco-milk-tea','Hazelnut Choco Milk Tea',27000,'Tea','#815840'],
  ['hazelnut-dutch-choco','Hazelnut Dutch Choco',35000,'Chocolate','#725143'],
  ['milk-oreo-crumble','Milk Oreo Crumble',33000,'Non-Coffee','#6d625a'],
  ['butterscotch-sea-salt-crumble','Butterscotch Sea Salt Crumble',29000,'Specialty','#ae8c69'],
  ['original-palm-sugar-milky-speculoos','Original Palm Sugar Milky Speculoos',30000,'Specialty','#aa7748'],
  ['thai-tea-loaded','Thai Tea Loaded',34000,'Tea','#c77b36'],
  ['oatside-matcha-latte','Oatside Matcha Latte',31000,'Matcha','#8a9d65']
].map(([id,name,price,category,color,tag]) => ({id,name,price,category,color,tag}));

export const GROUP_CATALOG = [
  ['group-americano-1l','Americano',95000,'group-americano-1l'],
  ['group-thai-tea-1l','Thai Tea',105000,'group-thai-tea-1l'],
  ['group-ex-memory-coffee-1l','Ex Memory Coffee',115000,'group-former-memories-1l'],
  ['group-black-palm-sugar-milk-coffee-1l','Black Palm Sugar Milk Coffee',120000,'group-black-palm-sugar-1l'],
  ['group-caramel-macchiato-1l','Caramel Macchiato',125000,'group-caramel-macchiato-1l']
].map(([id,name,price,image]) => ({id,name,price,image}));

export const PRODUCT_BY_ID = new Map(PRODUCT_CATALOG.map(product => [product.id, product]));
export const GROUP_BY_ID = new Map(GROUP_CATALOG.map(product => [product.id, product]));
export const formatRupiah = value => `Rp${Number(value).toLocaleString('id-ID')}`;

export function calculateOrderTotal(items, groupOrder = null) {
  const individualTotal = items.reduce((sum, item) => {
    const product = PRODUCT_BY_ID.get(item.productId);
    return sum + (product ? product.price * item.quantity : 0);
  }, 0);
  const group = groupOrder && GROUP_BY_ID.get(groupOrder.productId);
  return individualTotal + (group ? group.price * groupOrder.quantity : 0);
}
