import assert from 'node:assert/strict';
import test from 'node:test';
import { calculateOrderTotal, formatRupiah } from './catalog.js';

test('calculates required fundraiser totals from numeric catalog prices', () => {
  assert.equal(60000 * 2 + 95000, 215000);
  assert.equal(calculateOrderTotal([{productId:'black-palm-sugar-milk-coffee', quantity:2}], {productId:'group-americano-1l', quantity:1}), 147000);
  assert.equal(calculateOrderTotal([{productId:'caramel-macchiato', quantity:3}]), 102000);
  assert.equal(calculateOrderTotal([{productId:'matcha-latte', quantity:2}], {productId:'group-caramel-macchiato-1l', quantity:2}), 312000);
});

test('formats rupiah without using labels as data', () => {
  assert.equal(formatRupiah(26000), 'Rp26.000');
  assert.equal(formatRupiah(147000), 'Rp147.000');
  assert.equal(formatRupiah(1250000), 'Rp1.250.000');
});
