// NSA Care × Kopi Kenangan order endpoint. Deploy as a Google Apps Script Web App.
// Set SHEET_ID to the ID from the Google Sheet URL before deploying.
const SHEET_ID = 'PASTE_GOOGLE_SHEET_ID_HERE';
const SHEET_NAME = 'Orders';
const PRODUCTS = {
  'black-palm-sugar-milk-coffee':['Black Palm Sugar Milk Coffee',26000], 'caramel-macchiato':['Caramel Macchiato',34000], 'americano':['Americano',25000], 'matcha-latte':['Matcha Latte',31000], 'oreo-shake':['Oreo Shake',30000], 'kenangan-milk-tea':['Kenangan Milk Tea',25000], 'latte':['Latte',28000], 'milo-dinosaurus':['Milo Dinosaurus',27000], 'og-thai-tea':['OG Thai Tea',26000], 'dutch-chocolate':['Dutch Chocolate',30000], 'creamy-aren-latte':['Creamy Aren Latte',28000], 'former-memories-coffee':['Former Memories Coffee',26000], 'hazelnut-latte':['Hazelnut Latte',32000], 'matcha-espresso':['Matcha Espresso',32000], 'mocha-latte':['Mocha Latte',35000], 'vanilla-latte':['Vanilla Latte',32000], 'cappuccino':['Cappuccino',28000], 'caramel-latte':['Caramel Latte',32000], 'dua-shot-iced-shaken':['Dua Shot Iced Shaken',32000], 'butterscotch-aren-latte':['Butterscotch Aren Latte',26000], 'avocado-coffee':['Avocado Coffee',34000], 'taro-cloud-latte':['Taro Cloud Latte',29000], 'caramel-dutch-choco':['Caramel Dutch Choco',35000], 'hazelnut-choco-milk-tea':['Hazelnut Choco Milk Tea',27000], 'hazelnut-dutch-choco':['Hazelnut Dutch Choco',35000], 'milk-oreo-crumble':['Milk Oreo Crumble',33000], 'butterscotch-sea-salt-crumble':['Butterscotch Sea Salt Crumble',29000], 'original-palm-sugar-milky-speculoos':['Original Palm Sugar Milky Speculoos',30000], 'thai-tea-loaded':['Thai Tea Loaded',34000], 'oatside-matcha-latte':['Oatside Matcha Latte',31000]
};
const GROUPS = {
  'group-americano-1l':['Americano — 1 Liter',95000], 'group-thai-tea-1l':['Thai Tea — 1 Liter',105000], 'group-ex-memory-coffee-1l':['Ex Memory Coffee — 1 Liter',115000], 'group-black-palm-sugar-milk-coffee-1l':['Black Palm Sugar Milk Coffee — 1 Liter',120000], 'group-caramel-macchiato-1l':['Caramel Macchiato — 1 Liter',125000]
};
const HEADERS = ['Timestamp','Order ID','Name','Class','Customer Type','WhatsApp Number','Drink 1','Quantity 1','Subtotal 1','Drink 2','Quantity 2','Subtotal 2','Drink 3','Quantity 3','Subtotal 3','Drink 4','Quantity 4','Subtotal 4','Drink 5','Quantity 5','Subtotal 5','1 Liter Drink','1 Liter Quantity','1 Liter Subtotal','TOTAL PRICE','Payment Method','Notes','Payment Status','Order Status'];

function doPost(event) {
  try {
    const order = JSON.parse(event.postData.contents);
    const result = validateAndPrice(order);
    const sheet = getSheet();
    sheet.appendRow([new Date(), result.orderId, order.customer.name.trim(), order.customer.className.trim(), order.customer.customerType, order.customer.whatsapp.trim(), ...result.itemColumns, result.groupName, result.groupQuantity, result.groupSubtotal, result.total, order.paymentMethod, (order.notes || '').trim(), 'UNPAID', 'REQUESTED']);
    return json({success:true, orderId:result.orderId, total:result.total});
  } catch (error) {
    return json({success:false, error:error.message || 'Unable to save order'});
  }
}

function validateAndPrice(order) {
  if (!order || !order.customer) throw new Error('Invalid order');
  if (!String(order.customer.name || '').trim() || !String(order.customer.className || '').trim()) throw new Error('Name and class are required');
  if (['Student','Teacher'].indexOf(order.customer.customerType) === -1) throw new Error('Invalid customer type');
  if (!String(order.customer.whatsapp || '').trim()) throw new Error('WhatsApp number is required');
  if (['QRIS','Cash','Bank Transfer'].indexOf(order.paymentMethod) === -1) throw new Error('Invalid payment method');
  if (order.confirmed !== true) throw new Error('Confirmation is required');
  if (!Array.isArray(order.items) || order.items.length < 1 || order.items.length > 5) throw new Error('Choose one to five individual drinks');
  const seen = {};
  let total = 0;
  const itemColumns = [];
  order.items.forEach(item => {
    if (!PRODUCTS[item.productId] || seen[item.productId]) throw new Error('Invalid or duplicate drink');
    if (!Number.isInteger(item.quantity) || item.quantity < 1) throw new Error('Quantity must be a whole number of at least 1');
    seen[item.productId] = true;
    const [name, price] = PRODUCTS[item.productId];
    const subtotal = price * item.quantity;
    total += subtotal;
    itemColumns.push(name, item.quantity, subtotal);
  });
  while (itemColumns.length < 15) itemColumns.push('', '', '');
  let groupName = '', groupQuantity = '', groupSubtotal = '';
  if (order.groupOrder) {
    const group = GROUPS[order.groupOrder.productId];
    if (!group || !Number.isInteger(order.groupOrder.quantity) || order.groupOrder.quantity < 1) throw new Error('Invalid 1 Liter order');
    groupName = group[0]; groupQuantity = order.groupOrder.quantity; groupSubtotal = group[1] * groupQuantity; total += groupSubtotal;
  }
  const orderId = String(order.orderId || '').match(/^NSA-\d{8}-[A-Z0-9]{4,}$/) ? order.orderId : `NSA-${Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMdd')}-${Utilities.getUuid().slice(0,5).toUpperCase()}`;
  return {orderId, itemColumns, groupName, groupQuantity, groupSubtotal, total};
}

function getSheet() {
  if (SHEET_ID === 'PASTE_GOOGLE_SHEET_ID_HERE') throw new Error('Sheet is not configured');
  const spreadsheet = SpreadsheetApp.openById(SHEET_ID);
  const sheet = spreadsheet.getSheetByName(SHEET_NAME) || spreadsheet.insertSheet(SHEET_NAME);
  if (sheet.getLastRow() === 0) sheet.appendRow(HEADERS);
  return sheet;
}

function json(value) {
  return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);
}
