import { PRODUCT_CATALOG, GROUP_CATALOG, PRODUCT_BY_ID, GROUP_BY_ID, calculateOrderTotal, formatRupiah } from './catalog.js';

// Paste the deployed Google Apps Script Web App URL here after following README.md.
const ORDER_ENDPOINT = '';
const MAX_DRINKS = 5;
const form = document.querySelector('#orderForm');
const slots = document.querySelector('#drinkSlots');
const addDrinkButton = document.querySelector('#addDrink');
const groupToggle = document.querySelector('#addGroupOrder');
const groupFields = document.querySelector('#groupFields');
const breakdown = document.querySelector('#orderBreakdown');
const totalValue = document.querySelector('#totalValue');
const feedback = document.querySelector('#orderFeedback');

const selectOptions = (catalog, placeholder) => `<option value="">${placeholder}</option>${catalog.map(item => `<option value="${item.id}">${item.name} — ${formatRupiah(item.price)}</option>`).join('')}`;

function createSlot(index) {
  const isFirst = index === 1;
  const element = document.createElement('fieldset');
  element.className = 'drink-slot';
  element.dataset.slot = index;
  element.innerHTML = `<legend>Drink ${index}</legend>
    <label>Choose a drink<select class="drink-select" name="drink-${index}" ${isFirst ? 'required' : ''}>${selectOptions(PRODUCT_CATALOG, 'Select a drink')}</select></label>
    <label>Quantity<input class="drink-quantity" name="quantity-${index}" type="number" inputmode="numeric" min="1" step="1" value="1" required></label>
    ${isFirst ? '' : '<button class="remove-drink" type="button">Remove drink</button>'}`;
  slots.append(element);
}

function currentItems() {
  return [...slots.querySelectorAll('.drink-slot')].flatMap(slot => {
    const productId = slot.querySelector('.drink-select').value;
    const quantity = Number(slot.querySelector('.drink-quantity').value);
    return productId && Number.isInteger(quantity) && quantity >= 1 ? [{productId, quantity}] : [];
  });
}

function currentGroupOrder() {
  if (!groupToggle.checked) return null;
  const productId = document.querySelector('#groupDrink').value;
  const quantity = Number(document.querySelector('#groupQuantity').value);
  return productId && Number.isInteger(quantity) && quantity >= 1 ? {productId, quantity} : null;
}

function updateSelectOptions() {
  const selected = currentItems().map(item => item.productId);
  slots.querySelectorAll('.drink-select').forEach(select => {
    [...select.options].forEach(option => {
      option.disabled = Boolean(option.value && option.value !== select.value && selected.includes(option.value));
    });
  });
}

function renderTotal() {
  const items = currentItems();
  const group = currentGroupOrder();
  const lines = items.map(({productId, quantity}) => {
    const product = PRODUCT_BY_ID.get(productId);
    return `<div class="total-line"><span>${product.name}<small>${formatRupiah(product.price)} × ${quantity}</small></span><strong>${formatRupiah(product.price * quantity)}</strong></div>`;
  });
  if (group) {
    const product = GROUP_BY_ID.get(group.productId);
    lines.push(`<div class="total-line"><span>${product.name} <small>1 Liter · ${formatRupiah(product.price)} × ${group.quantity}</small></span><strong>${formatRupiah(product.price * group.quantity)}</strong></div>`);
  }
  breakdown.innerHTML = lines.length ? lines.join('') : '<p class="total-empty">Choose a drink to see your total.</p>';
  totalValue.textContent = formatRupiah(calculateOrderTotal(items, group));
  addDrinkButton.hidden = slots.children.length >= MAX_DRINKS;
}

function validateOrder(items, group) {
  if (!items.length) return 'Choose at least one drink.';
  const rawSlots = [...slots.querySelectorAll('.drink-slot')];
  if (rawSlots.some(slot => !slot.querySelector('.drink-select').value || !Number.isInteger(Number(slot.querySelector('.drink-quantity').value)) || Number(slot.querySelector('.drink-quantity').value) < 1)) return 'Each selected drink needs a whole-number quantity of at least 1.';
  if (groupToggle.checked && !group) return 'Choose a 1 Liter drink and enter a whole-number quantity of at least 1.';
  if (new Set(items.map(item => item.productId)).size !== items.length) return 'Choose each individual drink only once.';
  return '';
}

function showFeedback(message, kind = 'error') {
  feedback.className = `order-feedback ${kind}`;
  feedback.textContent = message;
  feedback.hidden = false;
}

function createOrderId() {
  const stamp = new Date().toISOString().slice(0, 10).replaceAll('-', '');
  const suffix = crypto.getRandomValues(new Uint32Array(1))[0].toString(36).toUpperCase().slice(-5);
  return `NSA-${stamp}-${suffix}`;
}

function orderPayload(items, group) {
  return {
    orderId: createOrderId(),
    customer: {
      name: form.elements.name.value.trim(),
      className: form.elements.className.value.trim(),
      customerType: form.elements.customerType.value,
      whatsapp: form.elements.whatsapp.value.trim()
    },
    items,
    groupOrder: group,
    paymentMethod: form.elements.paymentMethod.value,
    notes: form.elements.notes.value.trim(),
    confirmed: form.elements.confirmed.checked
  };
}

function showSuccess(result, payload) {
  const total = result.total ?? calculateOrderTotal(payload.items, payload.groupOrder);
  document.querySelector('#orderFormPanel').hidden = true;
  document.querySelector('#orderSuccess').hidden = false;
  document.querySelector('#successOrderId').textContent = result.orderId || payload.orderId;
  document.querySelector('#successTotal').textContent = formatRupiah(total);
  document.querySelector('#orderSuccess').scrollIntoView({behavior: 'smooth', block: 'center'});
}

createSlot(1);
document.querySelector('#groupDrink').innerHTML = selectOptions(GROUP_CATALOG, 'Select a 1 Liter drink');
renderTotal();

addDrinkButton.addEventListener('click', () => {
  createSlot(slots.children.length + 1);
  updateSelectOptions();
  renderTotal();
});
slots.addEventListener('click', event => {
  const button = event.target.closest('.remove-drink');
  if (!button) return;
  button.closest('.drink-slot').remove();
  [...slots.children].forEach((slot, index) => {
    const number = index + 1;
    slot.dataset.slot = number;
    slot.querySelector('legend').textContent = `Drink ${number}`;
  });
  updateSelectOptions();
  renderTotal();
});
slots.addEventListener('input', () => { updateSelectOptions(); renderTotal(); });
slots.addEventListener('change', () => { updateSelectOptions(); renderTotal(); });
groupToggle.addEventListener('change', () => {
  groupFields.hidden = !groupToggle.checked;
  document.querySelector('#groupDrink').required = groupToggle.checked;
  document.querySelector('#groupQuantity').required = groupToggle.checked;
  renderTotal();
});
groupFields.addEventListener('input', renderTotal);
groupFields.addEventListener('change', renderTotal);

form.addEventListener('submit', async event => {
  event.preventDefault();
  feedback.hidden = true;
  if (!form.reportValidity()) return;
  const items = currentItems();
  const group = currentGroupOrder();
  const orderError = validateOrder(items, group);
  if (orderError) return showFeedback(orderError);
  if (!ORDER_ENDPOINT) return showFeedback('Ordering is being connected to the fundraiser records. Your details are still here; please try again shortly or contact us on WhatsApp.');
  const payload = orderPayload(items, group);
  const submitButton = form.querySelector('[type="submit"]');
  submitButton.disabled = true;
  submitButton.textContent = 'Submitting…';
  try {
    const response = await fetch(ORDER_ENDPOINT, {method: 'POST', headers: {'Content-Type': 'text/plain;charset=utf-8'}, body: JSON.stringify(payload)});
    const result = await response.json();
    if (!response.ok || !result.success) throw new Error(result.error || 'Submission failed');
    showSuccess(result, payload);
  } catch (error) {
    showFeedback('Your order could not be submitted. Please try again or contact us on WhatsApp.');
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = 'Submit order';
  }
});

document.querySelector('#returnToMenu').addEventListener('click', () => {
  form.reset();
  slots.innerHTML = '';
  createSlot(1);
  groupFields.hidden = true;
  document.querySelector('#orderSuccess').hidden = true;
  document.querySelector('#orderFormPanel').hidden = false;
  updateSelectOptions();
  renderTotal();
  document.querySelector('#menu').scrollIntoView({behavior: 'smooth'});
});
